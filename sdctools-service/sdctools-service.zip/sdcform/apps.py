from django.apps import AppConfig


class SdcformConfig(AppConfig):
    name = 'sdcform'
