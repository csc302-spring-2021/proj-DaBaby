from django.apps import AppConfig


class SdcformresponseConfig(AppConfig):
    name = 'sdcformresponse'
