from django.apps import AppConfig


class BackendApiConfig(AppConfig):
    name = 'BackendApi'
